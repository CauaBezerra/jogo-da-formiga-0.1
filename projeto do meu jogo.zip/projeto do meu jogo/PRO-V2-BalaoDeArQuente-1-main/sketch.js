var formiga, formigaImg;
var teste;
var chocolate,chocolateImg;
var barreira1,barreira2,barreira3,barreira4;
var esquerda,direita,baixo,cima;
function preload(){
  formigaImg = loadImage("assets/formiga.png");

  chocolateImg = loadImage("assets/Barra-chocolate.png");
}

function setup(){
  formiga = createSprite(200,200,10,10);
  formiga.addImage(formigaImg);
  formiga.scale = 0.15;

  teste = createSprite(200,300,20,20);
  barreira1 = createSprite(20,400,20,780);
  barreira2 = createSprite(400,20,780,20);
  barreira3 = createSprite(800,400,20,780);
  barreira4 = createSprite(410,800,800,20);
}

function draw() {
  
  background("green");

  if(keyDown("up") && cima === true){
    formiga.y += -3;
  }
  if(keyDown("left") && esquerda === true){
    formiga.x += -3;
  }
  if(keyDown("down") && baixo === true){
    formiga.y += 3;
  }
  if(keyDown("right") && direita === true){
    formiga.x += 3;
  }

  if(formiga.isTouching(barreira1)){
    esquerda = false;
  }else{
    esquerda = true;
  }
  if(formiga.isTouching(barreira2)){
    cima = false;
  }else{
    cima = true;
  }
  if(formiga.isTouching(barreira3)){
    direita = false;
  }else{
    direita = true;
  }
  if(formiga.isTouching(barreira4)){
    baixo = false;
  }else{
    baixo = true;
  }

  //barreira1.visible = false;
  //barreira2.visible = false;
  //barreira3.visible = false;
  //barreira4.visible = false;
  
    doce();

  camera.position.x = formiga.position.x;
  camera.position.y = formiga.position.y;

        drawSprites();
}

function doce(){
  if(chocolate === null){
  chocolate = createSprite(200,300,10,10);
  chocolate.addImage(chocolateImg);
  chocolate.scale = 0.3;
  chocolate.x = Math.round(random(40,760));
  chocolate.y = Math.round(random(40,760));
  }
}
